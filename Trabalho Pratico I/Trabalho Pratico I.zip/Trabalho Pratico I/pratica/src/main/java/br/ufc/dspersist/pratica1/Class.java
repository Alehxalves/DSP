package br.ufc.dspersist.pratica1;

// Characters classes
public enum Class {
    KNIGHT,
    MAGE,
    PALADIN,
    DRUID;
}
