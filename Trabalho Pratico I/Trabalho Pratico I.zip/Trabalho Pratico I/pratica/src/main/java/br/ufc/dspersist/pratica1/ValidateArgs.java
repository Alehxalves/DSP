package br.ufc.dspersist.pratica1;

public class ValidateArgs {
    // true args validos, false args invalidos
    public static boolean validate(String[] args) {
        return args.length > 0 ? true : false;
    }
}
